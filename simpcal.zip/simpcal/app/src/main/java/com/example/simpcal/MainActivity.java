package com.example.simpcal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText num1,num2;
    TextView Res;
    Button cal;
    RadioButton a,s,m,d;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num1=findViewById(R.id.no1);
        num2=findViewById(R.id.no2);
        Res=findViewById(R.id.result);
        cal=findViewById(R.id.buttonok);
        a=findViewById(R.id.add);
        s=findViewById(R.id.sub);
        m=findViewById(R.id.mul);
        d=findViewById(R.id.div);

        cal.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        double rs=0;
        if(num1.getText().toString().equals("") || num2.getText().toString().equals(""))
            Toast.makeText(getApplicationContext(),"please enter values of both numbers",Toast.LENGTH_LONG).show();
        else {
            double n1 = Double.parseDouble(num1.getText().toString());
            double n2 = Double.parseDouble(num2.getText().toString());
            if(a.isChecked()){
               rs = n1+ n2;
            }
            else if(s.isChecked()){
               rs = n1 - n2 ;
            }
            else if(m.isChecked()){
                rs= n1*n2;

            }
            else if(d.isChecked()){
                rs=n1/n2;

            }
            String r = String.format("%.3f",rs);
            Res.setText(r);
        }
    }
}
